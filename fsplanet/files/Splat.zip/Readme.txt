There are 3 variations of the enhanced cross hair found in 3 folders.
V1, V2, V3. In these folders you will find Splat.bmp
Copy the version you want and paste in the following folder.
C:\Program Files\Acclaim Entertainment\Forsaken\Data\Textures
Overwrite existing file. Start game, Enjoy.

All are .bmp format created in MS Paint.
The default image Splat.bmp is also provided as a backup.
The .jpg files are to show an in game screenshot.
You must use the Extended cross hair enabler.
It turns extended cross hair on and off.